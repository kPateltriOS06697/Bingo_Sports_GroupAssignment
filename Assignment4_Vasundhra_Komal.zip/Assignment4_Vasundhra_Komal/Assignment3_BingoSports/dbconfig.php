<?php

$hostname ='localhost:3307';
$username ='root';
$password='';
$dbname ='dbbingo';
# make connection

$con= mysqli_connect($hostname,$username,$password,$dbname);

?>