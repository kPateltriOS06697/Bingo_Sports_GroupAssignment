<?php

$hostname ='localhost:3307';
$username ='root';
$password='';
$dbname ='dbBingo';
# make connection

$con= mysqli_connect($hostname,$username,$password,$dbname);

?>